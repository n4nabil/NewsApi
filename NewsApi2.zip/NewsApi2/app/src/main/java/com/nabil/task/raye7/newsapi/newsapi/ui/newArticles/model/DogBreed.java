package com.nabil.task.raye7.newsapi.newsapi.ui.newArticles.model;

import com.alimuzaffar.example.dogs.net.Api;

import androidx.databinding.BaseObservable;
import retrofit2.Callback;

public class DogBreed extends BaseObservable {
    private String breed;

    public String getBreed() {
        return breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    public void fetchImages(Callback<DogBreedImages> callback) {
        Api.getApi().getImagesByBreed(this.breed).enqueue(callback);
    }
}
