package com.nabil.task.raye7.newsapi.newsapi.ui;

import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

import com.nabil.task.raye7.newsapi.newsapi.R;
import com.nabil.task.raye7.newsapi.newsapi.data.models.NewsResponse;
import com.nabil.task.raye7.newsapi.newsapi.data.remote.ApiFactory;
import com.nabil.task.raye7.newsapi.newsapi.data.remote.UsersService;
import com.nabil.task.raye7.newsapi.newsapi.databinding.ActivityMainBinding;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;


public class MainActivity extends AppCompatActivity {

    private CompositeDisposable compositeDisposable = new CompositeDisposable();

    private void fetchUsersList() {

//        AppController appController = AppController.create(MainActivity.this);
//        UsersService usersService = appController.getUserService();
        UsersService usersService = ApiFactory.create();

        Disposable disposable = usersService.fetchUsers()
//                .subscribeOn(appController.subscribeScheduler())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<NewsResponse>() {


                    @Override
                    public void accept(NewsResponse newsResponse) throws Exception {
                        Toast.makeText(MainActivity.this, "size " + newsResponse.getArticles().size(), Toast.LENGTH_SHORT).show();
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        Toast.makeText(MainActivity.this, "throwable " + throwable, Toast.LENGTH_SHORT).show();
                    }
                });

        compositeDisposable.add(disposable);
    }

    ActionBar actionBar;
    ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);

        binding = DataBindingUtil.setContentView(this, R.layout.activity_main);
        actionBar = getSupportActionBar();
        showNavigation();
//        showHeadlines();


    }

//
//    private void showHeadlines() {
//        HeadlineFragment navigationFragment = new HeadlineFragment();
//        actionBar.setTitle("Headlines");
//        loadFragment(navigationFragment);
//    }

    private void showNavigation() {
        binding.navigation.setOnNavigationItemSelectedListener(item -> {
            switch (item.getItemId()) {
                case R.id.navigation_headline:
                    actionBar.setTitle("Headlines");
//                    loadFragment(NewArticlesFragment.newInstance());
//                    return true;

                case R.id.navigation_favourite:
//                    FavouriteFragment favouriteFragment = new FavouriteFragment();
//                    ItemListDialogFragment favouriteFragment = new ItemListDialogFragment();
                    actionBar.setTitle("Favourite");
//                    loadFragment(favouriteFragment);
//                    return true;

                default:
                    actionBar.setTitle("Headlines");
//                    loadFragment(NewArticlesFragment.newInstance());
                    return true;
            }
        });
    }

    private void loadFragment(Fragment fragment) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.frame_container, fragment)
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void onBackPressed() {
        finish();
    }

}
